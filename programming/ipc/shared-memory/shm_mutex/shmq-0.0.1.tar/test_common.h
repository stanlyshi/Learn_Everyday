#ifndef __COM_H
#define __COM_H 1


#define MY_SHMQ_NAME    "shmqtest1"
#define MY_SHMQ_SIZE    256


static char test_context[] = {"ABCDEFGHIGKLMNOPQRSTUVWXYZ"};


#endif /*<__COM_H>*/