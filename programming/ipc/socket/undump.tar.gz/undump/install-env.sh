#!/bin/bash
#安装socat 荣涛
rpm -i socat-1.7.3.2-2.el7.x86_64.rpm 
